def iterateDictionary(some_list):
    for dict in some_list:
        print(f"first_name - {dict['first_name']}," , f"last_name - {dict['last_name']}")



def iterateDictionary2(key_name, some_list):
    for i in some_list:
        print(i[key_name])

 

students = [
         {'first_name':  'Michael', 'last_name' : 'Jordan'},
         {'first_name' : 'John', 'last_name' : 'Rosales'},
         {'first_name' : 'Mark', 'last_name' : 'Guillen'},
         {'first_name' : 'KB', 'last_name' : 'Tonel'}
    ]
iterateDictionary(students) 
iterateDictionary2('first_name', students)
iterateDictionary2('last_name' , students)